How to run:
1.compile
2.run configuration on NIOS II 
3. use WASD to move the tetris block (w is rotate, s is speed up, a and d is move side to side)
4. try to break lines by maneuvering the pieces
5. game stops when your pieces reach the top of the game board